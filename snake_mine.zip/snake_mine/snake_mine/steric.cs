﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace snake_mine
{
    class steric
    {
        public char Steric { get; set; }
        public int X { get; set; }
        public int Y { get; set; }

        public steric()
        {
            Steric = '*';
            X = 0;
            Y = 0;
        }
    }
}
